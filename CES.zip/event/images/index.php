<?php 
require( "../../include/connection.php" );
require( "../../include/functions.php" );
redirect("../index.php");
?>