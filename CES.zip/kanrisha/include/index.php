<?php 
if(!isset($_SESSION['admin'])){
   redirect("../index.php");
}
